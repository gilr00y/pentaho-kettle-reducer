# ReduceR
Provides generic, custom `reduce` functionality to Pentaho/Kettle/Spoon transformation steps.